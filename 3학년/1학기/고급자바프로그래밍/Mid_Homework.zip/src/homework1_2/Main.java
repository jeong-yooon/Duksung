package homework1_2;
import java.util.*;

public class Main {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num = 0;
		String iname = "";
		String idepartment = "";
		String iid = "";
		double igpa = 0;
	    String sname = "";
	    String key = null, value1, value2 = "";
	    double value3 = 0;
	    
	    Map<String, Student2> map = new HashMap<String, Student2>();	    
	    Set<String> keySet = null;
	    Iterator<String> keyIterator = null;
	    while(true) {
		    System.out.print("1.�л������߰� / 2.�л������˻� : ");
		    num = sc.nextInt();
		    switch(num) {
	    
		    case 1:
		    	System.out.print("�л� �̸� : ");
		    	iname = sc.next();
		    	System.out.print("�л� �а� : ");
		    	idepartment = sc.next();
		    	System.out.print("�л� �й� : ");
		    	iid = sc.next();
		    	System.out.print("�л� ������� : ");
		    	igpa = sc.nextDouble();
		    
		    	map.put(iname, new Student2(idepartment, iid, igpa));
		    	
		    	keySet = map.keySet();
		    	keyIterator = keySet.iterator();
		    	while(keyIterator.hasNext()) {
		    		key = keyIterator.next();
		    		value1 = map.get(key).getDepartment();
		    		value2 = map.get(key).getId();
		    		value3 = map.get(key).getGpa();
			    	System.out.println(key + "\t" + value1 + "\t" + value2 + "\t" + value3);
			    	
		    	}
		    	
		    	break;
	    	
		    case 2:
	    	
		    	System.out.print("�˻��� �л��̸��� �Է��ϼ��� : ");
		    	sname = sc.next();

		    	keySet = map.keySet();
		    	keyIterator = keySet.iterator();
		    	while(keyIterator.hasNext()) {
		    		key = keyIterator.next();
		    		value1 = map.get(key).getDepartment();
		    		value2 = map.get(key).getId();
		    		value3 = map.get(key).getGpa();
		    		if(sname.equals(key)) {
		    			System.out.println(key + "�� ��������� " + value3 + "�Դϴ�.");
		    		}
		    	}

		    	break;
	    
		    }
	    }
	    
	}

}
