package homework2;

public interface ExStack<T> {
	public T pop();
	public boolean push(T ob);
}
