package homework1_1;
import java.util.*;

public class Main {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num = 0;
		String iname = "";
		String idepartment = "";
		String iid = "";
		double igpa = 0;
	    String sname = "";
	    
		ArrayList<Student> list = new ArrayList<Student>();
	    
	    while(true) {
		    System.out.print("1.�л������߰� / 2.�л������˻� : ");
		    num = sc.nextInt();
		    switch(num) {
	    
	    
		    case 1:
		    	System.out.print("�л� �̸� : ");
		    	iname = sc.next();
		    	System.out.print("�л� �а� : ");
		    	idepartment = sc.next();
		    	System.out.print("�л� �й� : ");
		    	iid = sc.next();
		    	System.out.print("�л� ������� : ");
		    	igpa = sc.nextDouble();
		    
		    	list.add(new Student(iname, idepartment, iid, igpa));
		    
		    	for(int i=0; i<list.size(); i++) {
		    		Student student = list.get(i);
		    		System.out.println(student.getName() + "\t" + student.getDepartment() + "\t" + student.getId() + "\t" + student.getGpa());
		    	}
		    	break;
	    	
		    case 2:
	    	
		    	System.out.print("�˻��� �л��̸��� �Է��ϼ��� : ");
		    	sname = sc.next();

		    	for(int i=0; i<list.size(); i++) {
		    		Student student = list.get(i);
		    		if(sname.equals(student.getName())) {
		    			System.out.println(sname + "�� ��������� " + student.getGpa() + "�Դϴ�.");
		    		}
		    	}
		    	break;
	    
		    }
	    }
	    
	}

}
