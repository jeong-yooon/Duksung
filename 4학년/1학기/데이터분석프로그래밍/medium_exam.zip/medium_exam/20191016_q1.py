from bs4 import BeautifulSoup
import urllib.request
import pandas as pd
import requests
import datetime


# [CODE 1]
def subway_store(result):
    result_test = []
    for page in range(1, 10):
        Hollys_url = f'https://www.subway.co.kr/storeSearch?page={page}&rgn1Nm=&rgn2Nm=#storeList'
        print(Hollys_url)
        # html = urllib.request.urlopen(Hollys_url)
        # html = urllib.request.urlopen(Hollys_url).read()

        response = requests.get(Hollys_url)

        if (response.status_code == 200):
            html = response.content
            soupHollys = BeautifulSoup(html, 'html.parser')
            tag_tbody = soupHollys.find('tbody')
            for store in tag_tbody.find_all('tr'):
                store_td = store.find_all('td')
                # store_num = store_td[0].string  # 숫자
                store_name = store_td[1].string  # 매장명
                store_address = store_td[2].string  # 주소
                store_service = store_td[3].string  # 주요서비스
                store_phone = store_td[4].string  # 연락처
                result.append([store_name] + [store_address] + [store_service] + [store_phone])
                result_test.append([store_name, store_address, store_service, store_phone])

                # for store in storeListli:
                #     store_name = store.find_element_by_css_selector('div.store_txt > p.name > span').text
                #     store_addr = store.find_element_by_css_selector('div.store_txt > p.address > span').text
                #     store_tel = store.fine_elements_by_css_selector('div.store_txt > p.tel > span').text
                #     print(store_name, store_addr, store_tel)
                #
                #     result.append([store_name, store_addr, store_tel])
        """    
        soupHollys = BeautifulSoup(html, 'html.parser')
        tag_tbody = soupHollys.find('tbody')
        for store in tag_tbody.find_all('tr'):
            store_td = store.find_all('td')
            store_name = store_td[1].string
            store_sido = store_td[0].string
            store_address = store_td[3].string
            store_phone = store_td[5].string
            result.append([store_name]+[store_sido]+[store_address]+[store_phone])
            result_test.append([store_name, store_sido, store_address, store_phone])
        """

    return


# [CODE 0]
def main():
    result = []

    print('Hollys store crawling >>>>>>>>>>>>>>>>>>>>>>>>>>')
    subway_store(result)  # [CODE 1] 호출
    hollys_tbl = pd.DataFrame(result, columns=('매장명', '매장주소', '24시간 서비스', '연락처'))
    hollys_tbl.to_csv('subway.csv', encoding='cp949', mode='w', index=True)


if __name__ == '__main__':
    main()

